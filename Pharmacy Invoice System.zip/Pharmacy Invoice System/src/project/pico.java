package project;
import org.picocontainer.*;
//import picoassignment.Converter;

public class pico {
    public static void main(String[] args) {
        MutablePicoContainer picoContainer2 = new DefaultPicoContainer();
        picoContainer2.addComponent(invoice.class);
        picoContainer2.getComponent(invoice.class).invoice();

    }
}
