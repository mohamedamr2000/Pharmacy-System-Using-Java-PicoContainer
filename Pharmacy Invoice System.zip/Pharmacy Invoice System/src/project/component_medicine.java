package project;
public class component_medicine {
   
  public static int[] GET_Medicine_Id()
  {
      int med_id[] = {1,2,3,4};
      return med_id;
  }
  
   public static String[] GET_Medicine_Name()
  {
      String med_name[] = {"Cataflam", "Asposed", "Paracetamlo", "Congestal"};
      return med_name;
  }
   
  public static int[] GET_Medicine_Price()
  {
      int med_price[] = {8, 15, 22, 4};
      return med_price;
  }
   
}
