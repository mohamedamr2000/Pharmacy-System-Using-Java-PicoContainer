package project;
import org.picocontainer.*;
import java.util.Scanner;
public class invoice {
    
    public void invoice(){
        // medicine component
        MutablePicoContainer picoContainer = new DefaultPicoContainer();
        picoContainer.addComponent(component_medicine.class);
        int med_id[] = picoContainer.getComponent(component_medicine.class).GET_Medicine_Id();
        String med_name[] = picoContainer.getComponent(component_medicine.class).GET_Medicine_Name();
        int med_price[] = picoContainer.getComponent(component_medicine.class).GET_Medicine_Price();
        // user componenet
                picoContainer.addComponent(user.class);
        int user_id[] = picoContainer.getComponent(user.class).GET_User_Id();
        String user_name[] = picoContainer.getComponent(user.class).GET_User_Name();
        int user_phone[] = picoContainer.getComponent(user.class).GET_User_Phone();
        
        System.out.println("Enter Customer ID");
       Scanner sc=new Scanner(System.in); 
       int input = sc.nextInt();  
       
       System.out.println("Enter Medicine ID");
       Scanner sc2=new Scanner(System.in); 
       int input2 = sc.nextInt();  
        
       System.out.println("Invoice");
       for (int i = 0; i < 3; i++)
       {
           if (input == user_id[i])
           {
               System.out.println("Customer Name: " + user_name[i]);
               System.out.println("Customer Phone Number: " + user_phone[i]);
           }
       }
        
       for (int i = 0; i < 4; i++)
       {
           if (input2 == med_id[i])
           {
               System.out.println("Medicine Name: " + med_name[i]);
               System.out.println("Medicine Price: " + med_price[i]);
           }
       }
    }
}
