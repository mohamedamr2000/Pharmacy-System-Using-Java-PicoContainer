package project;

public class user {
       
  public static int[] GET_User_Id()
  {
      int user_id[] = {1,2,3};
      return user_id;
  }
  
   public static String[] GET_User_Name()
  {
      String user_name[] = {"ahmed", "mohamed", "mostafa"};
      return user_name;
  }
   
  public static int[] GET_User_Phone()
  {
       int phone_number[] = {8544,1243,4545};
       return phone_number;
  }
  
}
